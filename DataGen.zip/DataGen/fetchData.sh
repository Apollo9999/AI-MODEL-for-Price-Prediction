#!/bin/bash

getNumberCountFromFile() {
	filename=$1
	appendInd=$2

	num=$(cat $filename | wc -l | xargs)
	if [ $appendInd == true ]; then
		num=$(($num + 1))
	fi
	echo $num
}

dumpDTDCResponse() {
    resp=$RESPONSE_DTDC

    # Check resp status
    status=$(echo $resp | jq -r '.status')
    echo $status
    iterationNum=$1
    sub_iterationNum=$2
    org_pin=$3
    dest_pin=$4
    dest_state=$5
    po_serviceable_val=$6
    dtdc_serviceable_val=$7
    box_type_val=$8
    dim_len_val=$9
    dim_wid_val=${10}
    dim_dep_val=${11}
    vol_weight_val=${12}
    weight_val=${13}
    dec_price_val=${14}
    sub_pin_iteration=${15}
    if [[ $status == "OK" ]]; then
        $(echo $resp | jq -r ".data[] | [\"$org_pin\",\"$dest_pin\",\"$dest_state\",\"$po_serviceable_val\",\"$dtdc_serviceable_val\",\"$box_type_val\",\"$dim_len_val\",\"$dim_wid_val\",\"$dim_dep_val\",\"$vol_weight_val\",\"$weight_val\",\"$dec_price_val\",\"DTDC\", .serviceType, .period, .price, .additionalPrice, .priceWithRiskSurcharge, .priceWithCarrierRiskSurcharge, .priceWithOwnerRiskSurcharge, .priceWithOptionalInsurance, .gstRate, .basePriceForDiscount, .GST, .GSTWithRiskSurcharge, .GSTWithCarrierRiskSurcharge, .GSTWithOwnerRiskSurcharge, .edd, .chargeableWeight] | @csv" > dtdcData2/"$iterationNum"_"$sub_iterationNum"_"$sub_pin_iteration"_dtdc.csv)
        $(cat  dtdcData2/"$iterationNum"_"$sub_iterationNum"_"$sub_pin_iteration"_dtdc.csv >> dtdcData2/"$batchst"_"$batchend"_master_dtdc.csv)

        # echo $rsp
    # else
    #     # handle case when pincode is not serviceable
    #     $(echo "$org_pin,$dest_pin,$dest_state,$po_serviceable_val,$dtdc_serviceable_val,$box_type_val,$dim_len_val,$dim_wid_val,$dim_dep_val,$vol_weight_val,$weight_val,$dec_price_val,DTDC,,,,,,,,,,,,,,,,," > dtdcData/"$iterationNum"_"$sub_iterationNum"_dtdc.csv)
    fi
}

dumpPorterResponse() {
    resp=$RESPONSE_PORTER

    #Check resp if it has quotations
    status=$(echo $resp | jq -r '.quotations | length')
    if [[ $status -gt 0 ]]; then
        echo "OK"
    else
        echo $resp | jq -r '.message'
    fi
    # echo $status
    iterationNum=$1
    sub_iterationNum=$2
    org_pin=$3
    dest_pin=$4
    dest_state=$5
    po_serviceable_val=$6
    box_type_val=$7
    dim_len_val=$8
    dim_wid_val=$9
    dim_dep_val=${10}
    vol_weight_val=${11}
    weight_val=${12}
    dec_price_val=${13}
    chargeable_wt_val=${14}
    sub_pin_iteration=${15}
    # TODO: Price needs to be divided by 100 since it is in paise
    if [[ $status -gt 0 ]]; then
        echo "Response rec"
        $(echo $resp | jq -r ".quotations[] | [\"$org_pin\",\"$dest_pin\",\"$dest_state\",\"$po_serviceable_val\",\"TRUE\",\"$box_type_val\",\"$dim_len_val\",\"$dim_wid_val\",\"$dim_dep_val\",\"$vol_weight_val\",\"$weight_val\",\"$dec_price_val\",.courier_partner.name, .courier_partner.service_type, .edd, .fare.minor_amount, .base_fare.minor_amount, .gst_amount.minor_amount, .edd_range.start_edd, .edd_range.end_edd, \"$chargeable_wt_val\"] | @csv" > porterData2/"$iterationNum"_"$sub_iterationNum"_"$sub_pin_iteration"_porter.csv)
        $(cat porterData2/"$iterationNum"_"$sub_iterationNum"_"$sub_pin_iteration"_porter.csv >> porterData2/"$batchst"_"$batchend"_master_porter.csv)
    # else
    #     # handle case when pincode is not serviceable or weight is more than 15 but less than 35

    fi
}


while IFS='\n' read var; do
    origin+=($var)
done < origin_pincode_compList

num_of_origin=$(getNumberCountFromFile origin_pincode_compList false)
num_of_dest=$(getNumberCountFromFile india_pincode_serviceable_dtdc true)
num_of_parcel_options=$(getNumberCountFromFile parcel_info.csv true)

export batchst=$1
export batchend=$2

for (( i = $1 ; i < $2 ; i++ ));
do
    echo "Iteration Number: $i"
    # Read origin pincode using a random number from list of origin pincode array
    minInd=0
    min=1
    min_price=500
    max_price=24500
    ind=$(shuf -i $minInd-$num_of_origin -n 1)
    org_pincode=${origin[$ind]}

    # Generate random number for index to read destination pincode
    dest_ind=$(shuf -i $min-$num_of_dest -n 1)
    dest_info=$(sed -n "${dest_ind}p" india_pincode_serviceable_dtdc)
    arr_dest_info=(${dest_info//,/ })
    
    dest_pincode=${arr_dest_info[0]}
    po_serviceable=${arr_dest_info[1]}
    state=${arr_dest_info[2]}
    dtdc_serviceable=${arr_dest_info[3]}
    echo "origin is $org_pincode and destination is $dest_pincode"
    echo "Dest Info: $dest_info"

    # Pick Random parcel info, based on prob we will choose weight within certain limits
    parcel_ind=$(shuf -i $min-$num_of_parcel_options -n 1)
	parcel_info=$(sed -n "${parcel_ind}p" parcel_info.csv)
        # This is only to test a particular parcel
        # parcel_info=$(sed -n "1p" testParcel.csv)
	echo "Parcel Info: $parcel_info"
	arr_parcel_info=(${parcel_info//,/ })

    box_type=${arr_parcel_info[0]}
    dim_len=${arr_parcel_info[1]}
    dim_wid=${arr_parcel_info[2]}
    dim_dep=${arr_parcel_info[3]}
    vol_weight=${arr_parcel_info[4]}
    minWeight_lim=${arr_parcel_info[5]}
    weight_lim=${arr_parcel_info[6]}

    maxWeight=$(echo $weight_lim*1000 | bc)
    maxWeightInt=${maxWeight/\.*/}

    minWeight=$(echo $minWeight_lim*1000 | bc)
    minWeightInt=${minWeight/\.*/}    

    randNum=$(shuf -i 0-10 -n 1)
    if [[ $randNum == 2 ]] || [[ $randNum == 4 ]]; then
        echo "Multi weight check in same route"
        attemptCounter=2
    else
        attemptCounter=1
    fi

    for (( j = 0 ; j < $attemptCounter ; j++ ));
    do
        echo "Sub-Iteration: $j"
        # Select a random weight
        weight=$(shuf -i $minWeightInt-$maxWeightInt -n 1)

        # Select a random Price based on commodity
        dec_price=$(shuf -i $min_price-$max_price -n 1)
        echo "Random weight in grams is $weight and Price is $dec_price"

        # Call Dtdc API 

        printf "DTDC: \n"
        echo "Pin iteration: 0"
        export RESPONSE_DTDC=$(curl --location "https://ebookingbackend.shipsy.in/getPriceAndTAT" --header 'Content-Type: application/json' --data '{"pickupPincode":"'${org_pincode}'","deliveryPincode":"'${dest_pincode}'","weight":"'${weight}'","courierType":"Non-Document","length":"'${dim_len}'","breadth":"'${dim_wid}'","height":"'${dim_dep}'","declaredPrice":"'${dec_price}'"}')
        # echo $RESPONSE_DTDC
        dumpDTDCResponse $i $j $org_pincode $dest_pincode $state $po_serviceable $dtdc_serviceable $box_type $dim_len $dim_wid $dim_dep $vol_weight $weight $dec_price 0

        echo "Pin iteration: 1"
        export RESPONSE_DTDC=$(curl --location "https://ebookingbackend.shipsy.in/getPriceAndTAT" --header 'Content-Type: application/json' --data '{"pickupPincode":"'${dest_pincode}'","deliveryPincode":"'${org_pincode}'","weight":"'${weight}'","courierType":"Non-Document","length":"'${dim_len}'","breadth":"'${dim_wid}'","height":"'${dim_dep}'","declaredPrice":"'${dec_price}'"}')
        # echo $RESPONSE_DTDC
        dumpDTDCResponse $i $j $dest_pincode $org_pincode $state $po_serviceable $dtdc_serviceable $box_type $dim_len $dim_wid $dim_dep $vol_weight $weight $dec_price 1

        printf "\n" 
        # Pick higher of vol weight or dead weight and call porter API

        volWeight=$(echo $vol_weight*1000 | bc)
        volWeightInt=${volWeight/\.*/}

        if [[ $volWeightInt -gt $weight ]]; then
            selWeight=$volWeightInt
        else
            selWeight=$weight
        fi

        randNum1=$(shuf -i 0-9 -n 1)
        randNum2=$(shuf -i 0-9 -n 1)
        randNum3=$(shuf -i 0-9 -n 1)
        randNum4=$(shuf -i 0-9 -n 1)
        randNum5=$(shuf -i 0-9 -n 1)
        randNum6=$(shuf -i 0-9 -n 1)
        num="9717"$randNum1$randNum2$randNum3$randNum4$randNum5$randNum6
        echo "number is $num"

        printf "Porter: \n"
        echo "Pin iteration: 0"
        export RESPONSE_PORTER=$(curl --location "https://courier-prod-ktor-external.porter.in/quotations/fetch_quotations" --header 'Content-Type: application/json' --data '{"mobile":'${num}',"pickup_pincode":'${org_pincode}',"drop_pincode":'${dest_pincode}',"item_volume":null,"pickup_lat_lng":{"lat":0,"lng":0},"weight_grams":'${selWeight}',"origin":"Website - Courier Main","web_tracking_id":"c7191600b91ad1acac0f98f11b196df6","is_business_query":false}')
        # echo $RESPONSE_PORTER
        dumpPorterResponse $i $j $org_pincode $dest_pincode $state $po_serviceable $box_type $dim_len $dim_wid $dim_dep $vol_weight $weight $dec_price $selWeight 0

        echo "Pin iteration: 1"
        export RESPONSE_PORTER=$(curl --location "https://courier-prod-ktor-external.porter.in/quotations/fetch_quotations" --header 'Content-Type: application/json' --data '{"mobile":'${num}',"pickup_pincode":'${dest_pincode}',"drop_pincode":'${org_pincode}',"item_volume":null,"pickup_lat_lng":{"lat":0,"lng":0},"weight_grams":'${selWeight}',"origin":"Website - Courier Main","web_tracking_id":"c7191600b91ad1acac0f98f11b196df6","is_business_query":false}')
        # echo $RESPONSE_PORTER
        dumpPorterResponse $i $j $dest_pincode $org_pincode $state $po_serviceable $box_type $dim_len $dim_wid $dim_dep $vol_weight $weight $dec_price $selWeight 1

    done

    echo "--------------------------------------------------------------------------------"
    printf "\n" 

done




# NOTE: We will add logic to do multiple different parcel in same route based on probability to get variance of weight/vol distribution -> Done